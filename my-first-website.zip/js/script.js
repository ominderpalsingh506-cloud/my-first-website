document.getElementById("contactBtn").addEventListener("click", function () {
  window.location.href = "mailto:yourname@email.com";
});